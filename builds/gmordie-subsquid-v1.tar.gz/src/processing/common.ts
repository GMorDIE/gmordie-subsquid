export const GMORDIE_PREFIX = 7013;
